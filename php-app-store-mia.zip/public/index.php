<?php

session_start();


$path =  $_SERVER['REQUEST_SCHEME'] . "://" . $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];
$path = str_replace("index.php", "", $path); //nakon show($path) vidimo da je index.php visak i onda ga riplejskujemo sa praznim stringom

define('ROOT', $path); //root je uvek isti zato ga definisemo kao konstantu
define('ASSETS', $path . "assets/");

include "../app/init.php";
//show($_SERVER); //sadrzi sve info o serveru
//show($path);
show(ROOT);


$app = new App();
