<?php

class User
{

    private $error = "";

    public function signup($POST)
    {
        $data = array();
        $db = Database::getInstance();

        $data['username'] = $POST['username'];
        $data['email'] = $POST['email'];
        $data['password'] = $POST['password'];
        $data['name'] = $POST['name'];
        $data['lastname'] = $POST['lastname'];

        if (empty($data['email']) || !preg_match("/^[0-9a-zA-Z_-]+@[a-zA-Z]+.[a-zA-Z]+$/", $data['email'])) {
            $this->error .= "Please enter valid email <br>";
        }

        if (empty($data['name'])) {
            $this->error .= "Please enter valid name <br>";
        }

        if (strlen($data['password']) < 4) {
            $this->error .= "Password must be atlest 4 character long <br>";
        }

        show($this->error);
        //ako nema gresaka cuvaj u bazu
        if ($this->error == "") {
            $data['rank'] = "customer";

            $query = "insert into users (username, email, password, name, lastname, rank) values (:username, :email, :password, :name, :lastname, :rank)";

            $result = $db->write($query, $data);

            if ($result) {
                header("Location: " . ROOT . "login");
                die;
            }
        }

        $_SESSION['error'] = $this->error;
    }

    public function login($POST)
    {

        $data = array();
        $db = Database::getInstance();

        $data['email'] = trim($POST['email']);
        $data['password'] = trim($POST['password']);

        if (empty($data['email']) || !preg_match("/^[a-zA-Z_-]+@[a-zA-Z]+.[a-zA-Z]+$/", $data['email'])) {
            $this->error .= "Please enter a valid email <br>";
        }

        if (strlen($data['password']) < 4) {
            $this->error .= "Password must be atleast 4 characters long <br>";
        }

        if ($this->error == "") {

            //comfirm
            $data['password'] = hash('sha1', $data['password']);

            //check if email already exists
            $sql = "select * from users where email = :email && password = :password limit 1";
            $result = $db->read($sql, $data);
            if (is_array($result)) {

                $_SESSION['user_id'] = $result[0]->url_address;
                header("Location: " . ROOT . "home");
                die;
            }

            $this->error .= "Wrong email or password <br>";
        }
    }

    public function get_user($url)
    {
    }
    public function check_login($redirect = false, $allowed = array())
    {

        $db = Database::getInstance();

        if (count($allowed) > 0) {

            $arr['id'] = $_SESSION['user_id'];
            $query = "select * from users where id_address = :id limit 1";
            $result = $db->read($query, $arr);

            if (is_array($result)) {
                $result = $result[0];
                if (in_array($result->rank, $allowed)) {

                    return $result;
                }
            }

            header("Location: " . ROOT . "login");
            die;
        } else {

            if (isset($_SESSION['user_id'])) {
                $arr = false;
                $arr['id'] = $_SESSION['user_id'];
                $query = "select * from users where url_id = :id limit 1";

                $result = $db->read($query, $arr);

                if (is_array($result)) {
                    return $result[0];
                }
            }

            if ($redirect) {
                header("Location: " . ROOT . "login");
                die;
            }
        }

        return false;
    }

    public function logout()
    {

        if (isset($_SESSION['user_id'])) {
            unset($_SESSION['user_id']);
        }

        header("Location: " . ROOT . "home");
        die;
    }
}
