<?php

class Order {
    public function get_all_orders() {
        $db = Database::getInstance();

        $query = "select * from orders";
        $orders = $db->read($query);

        return $orders;
    }
}