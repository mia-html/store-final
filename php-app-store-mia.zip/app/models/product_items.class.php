<?php

class Product_items{

    public function getall() {
        $db = Database::getInstance();

        $query = 'select * from products';
        $result = $db->read($query);
        return $result;
    }
    public function showwomen() {
        $db = Database::getInstance();

        $query = 'select * from products where category_id=1';
        $result = $db->read($query);
    }
    public function showmen() {
        $db = Database::getInstance();

        $query = 'select * from products where category_id=2';
        $result = $db->read($query);
    }
    public function showunisex() {
        $db = Database::getInstance();

        $query = 'select * from products where category_id=3';
        $result = $db->read($query);
    }
    public function addproduct() {
        $data = array();
        $db = Database::getInstance();

        $data['name'] = $POST['name'];
        $data['description'] = $POST['description'];
        $data['price'] = $POST['price'];
        $data['image'] = $POST['image'];
        $data['category_id'] = $POST['category_id'];

        $query = 'insert into products (name, description, price, image, category_id) values (:name, :description, :price, :image, :category_id)';

        $result = $db->write($query, $data);
    }
    public function deleteproduct() {
        $db = Database::getInstance();

        $id = $GET['id'];
        $query = "delete from products where id='$id'";
        $db->write($query);
    }
}