<?php

class Ajax_cart extends Controller {
    public function index(){

    }
    public function delete_item($data = ''){
        $obj = json_decode($data);
        $id = esc($obj->id);
    }
    public function edit_quantity($data = ''){

    }
}