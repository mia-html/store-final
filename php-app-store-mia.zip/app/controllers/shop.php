<?php

class Shop extends Controller {
    public function index() {
        $db = Database::getInstance();
        $product_items = $this->load_model('product_items');

        $query = 'select * from products';

        $products = $db->read($query);
    }
}