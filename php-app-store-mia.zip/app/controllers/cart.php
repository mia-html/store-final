<?php

class Cart extends Controller {
    public function index() {
        $user = $this->load_model('user');
        $db = Database::getInstance();

        $rows = false;
        $products_id = array();
    }
}