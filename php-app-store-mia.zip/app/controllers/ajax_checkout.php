<?php

class Ajax_checkout extends Controller {
    public function index($data_type = '', $id = '') {
        $id = $info->data->info;
    }

}