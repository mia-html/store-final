<?php

class Checkout extends Controller {
    public function index() {
        $user = $this->load_model('user');
        $db = Database::getInstance();

        $rows = false;
        $products_id = array();

        if(isset($_SESSION['CART'])) {
            $products_id = array_column($_SESSION['CART'], 'id');
            $rows = $db->read('select * from products');
        }
    }
}