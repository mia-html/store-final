<?php

class Home extends Controller
{
    public function index()
    //u suprotonom ce biti fatalna greska
    {
        //ovo nije dobro ne treba da imamo nista echo u kontrolerima
        //echo "this is a home class inside index method";

        $User = $this->load_model('User');
        $user_data = $User->check_login();

        if (is_array($user_data)) {
            $data['user_data'] = $user_data;
        }

        $data['page_title'] = "STORE";
        $this->view("home", $data); //view stranica ali bez .php
    }
}
