<?php

class Ajax_product extends Controller {
    public function index() {
        $db = Database::getInstance();

        $product = $this->load_model('product');
        $category = $this->load_model('category');
    }
}