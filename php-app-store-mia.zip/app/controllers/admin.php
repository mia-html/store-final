<?php

class Admin extends Controller
{
    public function index()

    {
        $User = $this->load_model('User');
        $user_data = $User->check_login(true, ['admin']);

        if (is_array($user_data)) {
            $data['user_data'] = $user_data;
        }

        $data['page_title'] = "ADMIN";
        $this->view("admin", $data);
    }
    public function products() {
        $User = $this->load_model('User');
        $user_data = $User->check_login(true, ['admin']);

        $products = $this->load_model('Product_items');
    }
}
