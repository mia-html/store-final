<?php

class Product_items extends Controller
{
    public function index()
    {
        $data['page_title'] = "STORE";
        $this->view("product_items", $data); //view stranica ali bez .php
    }
}
