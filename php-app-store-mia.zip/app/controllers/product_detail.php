<?php

class Product_detail extends Controller {
    public function index($id) {
        $id = esc(id);

        $user = $this->load_model('user');
        $db = Database::getInstance();

        $query = 'select * from products where id = $id';
        $row = $db->read($query);
    }
}