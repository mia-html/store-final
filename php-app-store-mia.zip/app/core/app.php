<?php

class App
{
    //difoltni kontroler i difoltni metod o kome ce biti reci kasnije
    protected $controller = "home";
    protected $method = "index";
    protected $params;

    public function __construct()
    {
        $url = $this->parseURL();
        // print_r($url); je prvo pisalo ali umesto toga zovemo show iz function.php
        //show($url);

        // u browser link public/products/food/milk/5///

        //posto je prvi paramerat u url-u kontroler moramo da vidimo da li postoji
        if (file_exists("../app/controllers/" . strtolower($url[0]) . ".php")) { //link prebacimo u mala slova da ne bude problema
            $this->controller = strtolower($url[0]); //sada znamo koji kontroler trazimo i kad nam ne treba vise unsetujemo
            unset($url[0]); //ako nesto krene po zlu uvek nam je difoltni home iz 6. linije
        }

        require "../app/controllers/" . $this->controller . ".php"; //zahtevamo otvaranje linka
        $this->controller = new $this->controller;

        if (isset($url[1])) {
            $url[1] = strtolower($url[1]);
            if (method_exists($this->controller, $url[1])) {
                $this->method = $url[1];
                unset($url[1]);
            }
        }

        $this->params = (count($url) > 0) ? $url : ["home"]; //ako nema parametara bice home
        //show(array_values($url));

        call_user_func_array([$this->controller, $this->method], $this->params);
    }

    private function parseURL()
    {

        $url = isset($_GET['url']) ? $_GET['url'] : "home"; //prikazi link , ako link nije validan stampaj home
        return explode("/", filter_var(trim($url, "/"), FILTER_SANITIZE_URL)); // "sanitajzing"  prebacuje link u niz, prvo je pisalo samo return $url
    }

    //u linku ce uvek da ide ime kontrolera pa ime metoda a ostalo su parametri iz baze
}
