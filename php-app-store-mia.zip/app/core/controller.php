<?php

class Controller
{
    public function view($path, $data = []) //data sci podaci koji nam ptrebaju page title i ostalo 
    //kada $data = [] inicijalizujemo na prazan niz postaje opciona
    {
        if (file_exists("../app/views/" . $path . ".php")) {
            include "../app/views/" .  $path . ".php";
        }
    }

    public function load_model($model)
    {
        if (file_exists("../app/models/" . strtolower($model) . ".class.php")) {
            include "../app/models/" .  strtolower($model) . ".class.php";
            return $a = new $model();
        }

        return false;
    }
}
