<?php

function show($data)
{
//    echo "<pre>";
//    print_r($data);
//    echo "</pre>";
}

function check_message()
{
    if (isset($_SESSION['error']) && $_SESSION['error'] != "") {
        echo $_SESSION['error'];
        unset($_SESSION['error']);
    }
}

function get_order_id() {
    $db = Database::getInstance();

    $rows = $db->read('select id from orders');
}

function get_total($rows) {
    $total = 0;

    foreach ($rows as $key => $row) {
        $total = $total + $row->cart_quantity * $row->price;
    }

    return $total;
}

function get_admin_count() {
    $db = Database::getInstance();

    $rows = $db->read("select id from users where rank = 'admin'");

    if (is_array($rows)) {
        return count($rows);
    }
    return 0;
}

function is_payed() {
    $db = Database::getInstance();

    $query = 'select id from payments where payed = 1';
    $payment = $db->read($query);
}
