<?php

define("WEBSITE_TITLE", 'MIA STORE');

define('DB_NAME', "store");
define('DB_USER', "root");
define('DB_PASS', "");
define('DB_TYPE', "mysql");
define('DB_HOST', "localhost");

define('DEBUG', true); //kad okacimo na sajt da ne vidimo previse gresaka

if (DEBUG) {
    ini_set('display_errors', 1);
} else {
    ini_set('display_errors', 0);
}
