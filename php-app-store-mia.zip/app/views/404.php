<!DOCTYPE html>
<html>

<head>Title</head>

<body>
<?php $this->view("header", $data); ?>

    <h1>404</h1>
</body>

</html>