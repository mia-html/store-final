
<header>
    <ul>
        <li><a class="link" href="product_items">Products</a></li>
        <li><a class="link" href="login">Log In</a></li>
        <li><a  class="link" href="admin">Admin</a></li>
    </ul>
</header>



<?php

if (isset($_SESSION['user_id'])) {
?>
    <h1>Ulogovan sa id-jem:</h1>
    <?php
    echo $_SESSION['user_id'];

    ?>
    <button>Logout</button>
<?php
}
?>

<style>
    body {
        margin: 0;
        padding: 0;
        background-color: #EBA48D;
        font-family: Avenir, Helvetica, Arial, sans-serif;

    }
    header {
        padding: 10px;
        width: 100%;
        height: 30px;
        background-color: white;
        line-height: 30px;
        display: flex;
        justify-content: center;
    }
    li {
        list-style-type: none;
        display: inline-block;
    }
    .link {
        font-weight: bold;
        color: #BAEB91;
        text-decoration: none;
        list-style-type: none;
        margin: 0 5px 0 5px;
        font-size: 1.24rem;
    }
    .link:hover {
         color: #6E9E47;
    }
    .view-product-btn {
        padding: 10px;
        background-color: #BAEB91;
        border: 2px solid #BAEB91;
        color: white;
        font-weight: bold;
        font-size: 1rem;
        border-radius: 5px;
        cursor: pointer;
    }
    .view-product-btn:hover {
        background-color: white;
        border: 2px solid #6E9E47;
        color: #6E9E47;

    }
</style>
