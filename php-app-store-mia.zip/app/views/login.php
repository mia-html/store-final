<!DOCTYPE html>
<html>

<body>
    <?php $this->view("header", $data); ?>
    <?php check_message() ?>
    <form method="post">
        <input type="email" name="email" placeholder="email" />
        <input type="password" name="password" placeholder="password" />
        <button class="view-product-btn" type="submit">Log in</button>
    </form>

    <a class="view-product-btn" href="<?= ROOT ?>signup">Create an account</a>


    <style>
        form {
            width: 80%;
            margin: 10%;
            background-color: white;
            box-shadow: 0 0 5px gray;
            border-radius: 5px;
            padding: 10px;
            display: flex;
            justify-content: space-around;
        }
        input {
            background-color: #EBA48D;
            color: #EBA48D;
            border: 2px solid #EBA48D;
            border-radius: 5px;
            height: 25px;
            margin-top: 5px;
        }
        input:focus {
             outline: none;
             border: 2px solid #EBA48D;
             background-color: white;
         }
        ::placeholder {
            color: white;
        }
        a.view-product-btn {
            display: flex;
            justify-content: center;
            width: 200px;
            margin: 0 auto;
        }
        @media (max-width: 650px) {
            form {
                display: flex;
                flex-direction: column;
                width: 50%;
                margin: 25%;
            }
            input, .view-product-btn, a.view-product-btn{
                width: 160px;
                margin: 25px auto;
                text-align: center;
            }
        }
    </style>
</body>

</html>