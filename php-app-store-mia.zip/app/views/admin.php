<!DOCTYPE html>
<html>

<body>

<?php $this->view("header", $data); ?>

    ADMIN
</body>

</html>