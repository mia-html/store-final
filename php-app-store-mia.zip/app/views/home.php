<!DOCTYPE html>
<html>

<body>
<?php $this->view("header", $data); ?>

    <h2>HOME PAGE</h2>
</body>

</html>