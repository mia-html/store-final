<!DOCTYPE html>
<html>

<body>
<input type="text" name="typedText" value=<?php echo $_POST['username'] ?> />
</body>

</html>
<?php

    // $servername = "localhost";
    // $username = "dumagus_matija";
    // $password = "matijadb123";
    // $dbname = "dumagus_emails";
//    $servername = "localhost";
//    $username = "root";
//    $password = "";
//    $dbname = "store";

    if(isset($_POST['username']) ) {

        $username = $_POST['username'];

        echo $username;

        var_dump($_POST['email']);
    }
//
//    // Create connection
//    $conn = new mysqli($servername, $username, $password, $dbname);
//        // Check connection
//
//    if ($conn->connect_error) {
//        die("Connection failed: " . $conn->connect_error);
//    }
//
//    $sql = "SELECT * FROM `email_records` WHERE `customer_email`='$customerEmail'";
//
//    $result = $conn->query($sql);
//    if(mysqli_num_rows($result) < 1){
//        $sql = "INSERT INTO `email_records` (`customer_email`) VALUES ('$customerEmail')";
//    }
//
//    if ($conn->query($sql) === TRUE) {
//        header("Location: index.php?result=success");
//    } else {
//       header("Location: index.php?result=error");
//    }
//
//    $conn->close();

?>