<!DOCTYPE html>
<html>


<?php check_message() ?>

<body>

<?php //$this->view("header", $data); ?>

    <form method="post" action="./adduser.php">
        <input type="text" name="username" placeholder="username" /></br>
        <input type="email" name="email" placeholder="email" /></br>
        <input type="password" name="password" placeholder="password" /></br>
        <input type="text" name="name" placeholder="name" /></br>
        <input type="text" name="lastname" placeholder="lastname" /></br>
        <button class="view-product-btn" type="submit" name="submit">Sign up</button>

    </form>
    <input type="text" name="typedText" value=<?php echo $_POST['username'] ?> />
<style lang="scss">
    form {
        width: 80%;
        margin: 10%;
        margin-bottom: 80%;
        background-color: white;
        box-shadow: 0 0 5px gray;
        border-radius: 5px;
        padding: 10px;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    input {
        background-color: #EBA48D;
        color: white;
        border: 2px solid #EBA48D;
        border-radius: 5px;
        height: 25px;
        margin-top: 5px;
        text-align: center;
        width: 300px;
    }
    input:focus {
        color: #EBA48D;
         outline: none;
         border: 2px solid #EBA48D;
         background-color: white;
    }
    ::placeholder {
        color: white;
    }
    .view-product-btn {
        margin-top: 30px;
        width: 300px;
    }
    @media (max-width: 650px) {
        form {
            display: flex;
            flex-direction: column;

        }
        input, .view-product-btn {
            width: 160px;
            margin: 15px auto;
        }
    }
</style>
</body>


</html>